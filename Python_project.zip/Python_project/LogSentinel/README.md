# LogSentinel: Server Log Analyzer & Threat Detector

LogSentinel is a command-line utility designed to parse web server logs (Nginx/Apache), analyze traffic patterns, and detect suspicious activities such as brute-force attacks.

## Environment Setup
Ensure you have Python 3.8+ installed.

1. Clone the repository and navigate to the folder:
   ```bash
   cd LogSentinel
   ```
2. (Optional but recommended) Create a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows use `venv\Scripts\activate`
   ```
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Usage

LogSentinel uses standard CLI arguments. You can view all options using the help command:
```bash
python main.py --help
```

### Basic Traffic Analysis
Analyze a log file and display the top 5 IPs:
```bash
python main.py --log-file samples/sample_access.log --top-ips 5
```

### Threat Detection
Enable brute-force detection heuristics:
```bash
python main.py --log-file samples/sample_access.log --detect-threats
```

### Export Results
Export the parsed top IP traffic data to a CSV file:
```bash
python main.py --log-file samples/sample_access.log --export-csv report.csv
```
